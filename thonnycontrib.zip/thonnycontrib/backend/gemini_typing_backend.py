import builtins
import json
import os
import random
import time
import urllib.error
import urllib.request
from pathlib import Path


# ============================================================
# CONFIG
# ============================================================

MODEL = os.environ.get("THONNY_GEMINI_MODEL", "gemini-3.8-flash")

MAX_RETRIES = 3
REQUEST_TIMEOUT = 90

# gemini_typing_backend.py
#       ↓ parents[0]
# backend/
#       ↓ parents[1]
# thonnycontrib/
PLUGIN_DIR = Path(__file__).resolve().parents[1]

# api.txt nằm trong thư mục thonnycontrib/
API_FILE = PLUGIN_DIR / "api.txt"

# Lưu response gần nhất cạnh plugin.
STATE_FILE = PLUGIN_DIR / "gemini_typing_response.json"


# Những lỗi nên retry cùng API key
RETRYABLE_ERRORS = {
    429,  # Too Many Requests
    500,  # Internal Server Error
    502,  # Bad Gateway
    503,  # Service Unavailable
    504,  # Gateway Timeout
}


# ============================================================
# API KEY
# ============================================================

_api_keys = []


def _load_api_keys():
    """
    Đọc API key từ api.txt.

    api.txt:
        KEY_1
        KEY_2
        KEY_3

    Có thể có dòng trống hoặc dòng bắt đầu bằng #.
    """

    global _api_keys

    if not API_FILE.exists():
        raise FileNotFoundError(
            f"Không tìm thấy api.txt tại:\n{API_FILE}"
        )

    keys = []

    with API_FILE.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()

            if not line:
                continue

            if line.startswith("#"):
                continue

            keys.append(line)

    if not keys:
        raise RuntimeError(
            f"api.txt không chứa API key:\n{API_FILE}"
        )

    _api_keys = keys

    return _api_keys


def api():
    """
    Load toàn bộ API key từ api.txt.

    Không cần truyền tham số:
        api()
    """

    return _load_api_keys()


# ============================================================
# GEMINI REQUEST
# ============================================================

def _make_request(api_key, message):
    """
    Gửi request tới Gemini.

    Trả về:
        (success, result)

    success=True:
        result là câu trả lời.

    success=False:
        result là HTTP status hoặc exception.
    """

    url = (
        "https://generativelanguage.googleapis.com/"
        f"v1beta/models/{MODEL}:generateContent"
    )

    payload = {
        "contents": [
            {
                "parts": [
                    {
                        "text": str(message)
                    }
                ]
            }
        ]
    }

    data = json.dumps(payload).encode("utf-8")

    request = urllib.request.Request(
        url,
        data=data,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "x-goog-api-key": api_key,
        },
    )

    try:
        with urllib.request.urlopen(
            request,
            timeout=REQUEST_TIMEOUT
        ) as response:

            raw = response.read().decode("utf-8")

            return True, _extract_response(raw)

    except urllib.error.HTTPError as e:
        return False, e.code

    except (
        urllib.error.URLError,
        TimeoutError,
        ConnectionError,
        OSError,
    ):
        return False, "network"


# ============================================================
# RESPONSE PARSER
# ============================================================

def _extract_response(raw):
    """
    Lấy text từ response của Gemini.
    """

    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return raw

    candidates = data.get("candidates", [])

    if not candidates:
        raise RuntimeError(
            "Gemini không trả về candidate."
        )

    parts = (
        candidates[0]
        .get("content", {})
        .get("parts", [])
    )

    texts = []

    for part in parts:
        text = part.get("text")

        if text:
            texts.append(text)

    result = "".join(texts).strip()

    if not result:
        raise RuntimeError(
            "Gemini trả về response rỗng."
        )

    return result


# ============================================================
# STATE
# ============================================================

def _save_response(response):
    """
    Lưu response mới nhất.
    """

    try:
        STATE_FILE.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        data = {
            "response": response,
            "timestamp": time.time(),
        }

        with STATE_FILE.open(
            "w",
            encoding="utf-8"
        ) as f:
            json.dump(
                data,
                f,
                ensure_ascii=False,
                indent=2
            )

    except Exception:
        # Không để lỗi lưu state làm hỏng request.
        pass


def _load_last_response():
    """
    Đọc response gần nhất.
    """

    try:
        if not STATE_FILE.exists():
            return ""

        with STATE_FILE.open(
            "r",
            encoding="utf-8"
        ) as f:
            data = json.load(f)

        return data.get("response", "")

    except Exception:
        return ""


# ============================================================
# REQUEST
# ============================================================

def request(message):
    """
    Gửi message tới Gemini.

    Cơ chế:
        Key 1
          ├─ retry 1
          ├─ retry 2
          └─ retry 3
              ↓
        Key 2
          ├─ retry 1
          ├─ retry 2
          └─ retry 3
              ↓
        ...

    Thành công:
        return câu trả lời của Gemini

    Thất bại toàn bộ:
        raise RuntimeError

    Không print log ra console.
    """

    global _api_keys

    if not _api_keys:
        _load_api_keys()

    if not _api_keys:
        raise RuntimeError(
            "Không có API key."
        )

    # Trộn thứ tự key để tránh luôn dùng một key trước.
    keys = list(_api_keys)
    random.shuffle(keys)

    last_error = None

    for api_key in keys:

        for _ in range(MAX_RETRIES):

            success, result = _make_request(
                api_key,
                message
            )

            if success:
                _save_response(result)
                return result

            last_error = result

            # Các lỗi cần retry.
            if result in RETRYABLE_ERRORS:
                time.sleep(1)
                continue

            # Lỗi key / authentication:
            # bỏ key hiện tại và chuyển sang key khác.
            if result in (400, 401, 403):
                break

            # Lỗi khác:
            # thử lại trước khi đổi key.
            time.sleep(1)

        # Key này hết lượt retry → chuyển key tiếp theo.

    raise RuntimeError(
        f"Không thể nhận phản hồi từ Gemini. "
        f"Lỗi cuối: {last_error}"
    )


# ============================================================
# THONNY PLUGIN
# ============================================================

def load_plugin(backend):
    """
    Entry point của Thonny backend plugin.

    Sau khi plugin được load, có thể gọi:

        api()

    và:

        request("Hello Gemini")
    """

    builtins.api = api
    builtins.request = request