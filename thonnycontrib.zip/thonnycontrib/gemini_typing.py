# -*- coding: utf-8 -*-
"""Toolbar character guide for Thonny. AI line 1 maps to editor line 2."""
import json
import os
import tkinter as tk
from tkinter import ttk

from thonny import get_workbench, get_thonny_user_dir

STATE_FILE = os.path.join(
    os.path.expanduser("~"),
    "AppData",
    "Roaming",
    "Thonny",
    "gemini_typing_response.json",
)
POLL_MS = 100
_button = None
_last_mtime = None
_response = ""

def _read_response():
    global _last_mtime, _response
    try:
        mtime = os.path.getmtime(STATE_FILE)
        if mtime == _last_mtime:
            return
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        _response = str(data.get("response", ""))
        _last_mtime = mtime
    except (OSError, ValueError, TypeError):
        pass

def _get_text_widget():
    try:
        editor = get_workbench().get_editor_notebook().get_current_editor()
        return editor.get_text_widget() if editor else None
    except Exception:
        return None

def _set_button(label, state):
    if _button is None:
        return
    colors = {
        "gray": ("#888888", "#ffffff"),
        "green": ("#239b56", "#ffffff"),
        "red": ("#d93025", "#ffffff"),
        "idle": (None, None),
    }
    bg, fg = colors[state]
    try:
        opts = {"text": label}
        if bg:
            opts.update(background=bg, foreground=fg)
        _button.configure(**opts)
    except tk.TclError:
        pass

def _refresh():
    _read_response()
    widget = _get_text_widget()
    if widget is None or not _response:
        _set_button("AI", "gray")
        get_workbench().after(POLL_MS, _refresh)
        return

    try:
        # Tk Text index is 1-based for lines, 0-based for columns.
        line, col = map(int, widget.index("insert").split("."))
        ai_index = line - 2  # AI line 1 -> editor line 2
        lines = _response.splitlines()
        if ai_index < 0 or ai_index >= len(lines):
            _set_button("AI", "gray")
        else:
            expected_line = lines[ai_index]
            if col >= len(expected_line):
                _set_button("✓", "green" if widget.get(f"{line}.{max(0, col-1)}", f"{line}.{col}") == expected_line[max(0, col-1):col] else "gray")
            else:
                expected = expected_line[col]
                # Cursor is immediately before expected character. Compare the
                # character at this column if it has already been entered.
                actual = widget.get(f"{line}.{col}", f"{line}.{col+1}")
                if actual == "":
                    state = "gray"
                elif actual == expected:
                    state = "green"
                else:
                    state = "red"
                _set_button("␠" if expected == " " else expected, state)
    except Exception:
        _set_button("AI", "gray")

    try:
        get_workbench().after(POLL_MS, _refresh)
    except Exception:
        pass

def _help():
    from tkinter import messagebox
    messagebox.showinfo(
        "Gemini Typing Assistant",
        'Run api("YOUR_KEY") then request("your prompt") in a CPython shell.\n\n'
        "AI response line 1 maps to editor line 2, line 2 to editor line 3, etc.\n"
        "Toolbar indicator: gray = pending, green = correct, red = incorrect.",
        parent=get_workbench(),
    )

def load_plugin():
    global _button
    wb = get_workbench()
    wb.add_command(
        command_id="gemini_typing_help",
        menu_name="tools",
        command_label="Gemini Typing Assistant",
        handler=_help,
        caption="AI",
        include_in_toolbar=True,
        group=90,
    )
    try:
        _button = wb.get_toolbar_button("gemini_typing_help")
    except Exception:
        _button = None
    wb.after(300, _refresh)
